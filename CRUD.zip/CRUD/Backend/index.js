const express =require('express');
const app =express();

const mongoose = require("mongoose");
const cors = require('cors')


require('./Db/Dbconn');


 
const PORT=8080






app.use(cors())

app.use(express.json());

const user_Route = require("./Routes/userRoutes")
app.use('/api',user_Route)


//dashboard route

app.listen(PORT,()=>{
    console.log(`server is started at port ${PORT}` );
 
    
})