//we have to register the user so we have to require this model
const User = require('../Model/UserModel');
//used to hash the password




//
const registerUser = async (req, res) => {
    try {
        const user = new User({

            name: req.body.name,
            email:req.body.email
          
        });

       
        const userData = await User.find({ email: user.email })
        // console.log(userData)
        if (userData && userData === null) {
            return res.status(422).json({ err: "email already exists" })
        }
        // else if (user.password != user.cpassword) {
        //     return res.status(422).json({ err: "password doesnot matches" })
        // }
         else {
            const user_data = await user.save()
           
            res.status(200).send({ success: true, data: user_data ,message:"Registration successful"})
        }

    } catch (error) {
        res.status(500).send(error.message);   
    }
}

//get data
const getdata = async(req,res)=>{
    try {
        const user = await User.find()
        res.status(200).json({data:user,sucess:true});   
    } catch (error) {
        res.status(500).send(error.message);   
        
    }
}


//update data
const updateData = async(req,res)=>{
    

    try {
        const {id}= req.params
        console.log("id",id)
        const user = await User.findByIdAndUpdate({_id:id},req.body,{new:true})
        console.log("user",user)
        res.status(200).json({data:user,sucess:true});  
        
    } catch (error) {
        console.log(error);
        res.status(500).send(error.message);   
        
    }
}

const deleteData = async(req,res)=>{
    

    try {
        const {id}= req.params
     
        const user = await User.findByIdAndDelete({_id:id})
     
        res.status(200).json({data:user,sucess:true,message:"Deleted"});  
        
    } catch (error) {
        console.log(error);
        res.status(500).send(error.message);   
        
    }
}


//individual data

const individual= async(req,res)=>{
    try {
        const {id}= req.params
        const user = await User.findById({_id:id})

    res.status(200).json({data:user,message:"Data fetched"})
    } catch (error) {
        
    }
}


module.exports = {
    registerUser,
    getdata,
    updateData,deleteData,
    individual
}