const express = require("express");

const user_route = express();

user_route.use(express.json());


const user_controller = require('../Controller/userController');



user_route.post ('/register',user_controller.registerUser);
user_route.get('/getdata',user_controller.getdata)
user_route.put('/updatedata/:id',user_controller.updateData)
user_route.delete('/deletedata/:id',user_controller.deleteData)
user_route.get("/getdataind/:id",user_controller.individual)

module.exports=user_route