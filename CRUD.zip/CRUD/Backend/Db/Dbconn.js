const mongoose = require('mongoose');
const DB= "mongodb+srv://Rahul:Rahul123@cluster0.xo20xr4.mongodb.net/?retryWrites=true&w=majority"
mongoose.connect(DB).then(()=>{
    console.log("connection succesful")
}).catch((err )=>console.log(err.message))

module.exports = {
    mongoose
};