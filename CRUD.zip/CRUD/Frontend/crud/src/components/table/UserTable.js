import React, { useState, useEffect, useContext } from 'react'
import { Link, useNavigate, useParams } from "react-router-dom"



const UserTable = () => {
    const navigate = useNavigate();
    const [getuserdata, setuserdata] = useState([]);
    const getdata = async () => {

        const res = await fetch("http://localhost:8080/api/getdata", {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        })
        const data = await res.json();
        console.log(data?.data);
        if (res.status === 422 || !data) {
            console.log("error ");
        } else {
            setuserdata(data?.data)
       
        }
    
    }
    useEffect(() => {
        getdata();
    }, [])

    const deleteRoom = async (id,name) => {
        const res2 = await fetch('http://localhost:8080/api/deletedata/' + id, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const deletedata = await res2.json();
        console.log(deletedata);

        if (res2.status === 422 || !deletedata) {
            alert("error");
        } else {
            alert(`${deletedata?.data?.name} room deleted`);

            getdata();
        }
    }

    // const deletealert = async (roomid, title) => {
    //     Modal.confirm({
    //         title: ` Are you sure you want to delete ${name} room?`,
    //         icon: < DeleteOutlineIcon />,
    //         maskClosable: true,
    //         cancelText: 'No',
    //         cancelButtonProps: { size: 'large' },
    //         okText: ' Yes ',
    //         okButtonProps: { size: 'large' },

    //         onOk() {
    //             deleteRoom(roomid)
    //             navigate("/rooms")
    //         },
    //     }).then(function () { }).catch(function () { })
    // }


  return (
    <div>
        <div className="mt-5">
                    <div className="container">
                        <h1 >All Room List</h1>
                        <div className="add_btn mt-2 mb-2">
                            <Link to="/" className="btn btn-primary">Add User</Link>
                        </div>

                        <table class="table">
                            <thead>
                                <tr className="table-dark" >
                                    <th scope="col">Id</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                 

                                    <th scope="col">Actions</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            {
                                getuserdata != "" ?
                                    <tbody>
                                        {
                                            getuserdata.map((element, id) => {
                                                return (
                                                    <>
                                                        <tr>
                                                            <th scope="row">{id + 1}</th>
                                                            <td>{element?.name}</td>
                                                            <td>{element?.email}</td>
                                                          
                                                           
                                                 
                                                            <td>
                                                                <td className="d-flex justify-content-between ">

                                                                    {/* <Link to={`/rooms/view/${element._id}`}> <button style={{ marginRight: 20 }} className="btn btn-success mt-2"><RemoveRedEyeIcon /></button></Link> */}
                                                                     <Link to={`edit/${element._id}`}>  <button style ={{marginRight:20}} className="btn btn-primary mt-2">Edit</button></Link> 

                                                                    <button className="btn btn-danger mt-2" onClick={() => deleteRoom(element?._id, element?.name)}>Delete</button>
                                                                </td>
                                                            </td>
                                                        </tr>
                                                    </>
                                                )
                                            })
                                        }
                                    </tbody> : <h4>There is no user created !!!<strong>Please add </strong></h4>  
                            }

                        </table>
                    </div>
                </div>
    </div>
  )
}

export default UserTable








