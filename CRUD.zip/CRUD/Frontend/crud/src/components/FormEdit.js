import React, { useContext, useEffect, useState } from 'react';
import { NavLink, useParams, useNavigate } from 'react-router-dom'



const FormEdit = () => {


    const navigate = useNavigate()
    const [inpval, setINP] = useState({
      name: "",
      email: "",
    });
  
    const setdata = (e) => {
      const { name, value } = e.target;
      setINP((preval) => {
        return {
          ...preval,
          [name]: value,
        };
      });
    };

    const { id } = useParams("");
    let data;
    const getdata = async () => {
        const res = await fetch(`http://localhost:8080/api/getdataind/${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        data = await res.json();
        if (res.status === 422 || !data) {
            console.log("error ");

        } else {
            setINP(data?.data)
        }
    }


    useEffect(() => {
        getdata()

    }, []);
  
    const updatedata = async (e) => {
      e.preventDefault();
      // setLoading(true)
  
      const { name, email } = inpval;
      //send data from front to back
      // if (title === "") {
      //     message.error("Please enter the title")
      //     console.log("s1")
      // } else if (title.replace(/\s/g, "").length <= 0) {
      //     message.error("No whitespace and empty field are allowed for title");
      //     return false;
      // }
      // else if (description === "") {
      //     message.error("Please enter the description")
  
      // } else if (description.replace(/\s/g, "").length <= 0) {
      //     message.error("No whitespace and empty field are allowed for description");
      //     return false;
  
      // }else if (description.length < 5 || description.length > 150) {
      //     message.error("Description should be greater than 5 character and less than 150 characters")
      //     // console.log(s3)
      // }
      // else if (amount === "") {
      //     message.error("Please enter the amount")
      // }
      // else if (Roomtitle === "") {
      //     message.error("Please enter the Roomtitle")
      // }
      // else {
  
      const res = await fetch("http://localhost:8080/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          email,
        }),
      });
  
      const data = await res.json();
  
      if (res.status === 422 || !data.data) {
        console.log("error ");
        alert("error");
      } else {
        alert("data updated");
        navigate('/table');
        // setUdata(data)
      }
    };
  return (
    <div>
    <form>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input
        type="email"
        class="form-control"
        id="exampleInputEmail1"
        aria-describedby="emailHelp"
        placeholder="Enter email"
        name="email"
        value={inpval.email}
        onChange={setdata}
      />
      <small id="emailHelp" class="form-text text-muted">
        We'll never share your email with anyone else.
      </small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Name</label>
      <input
        type="text"
        class="form-control"
        id="exampleInputPassword1"
        placeholder="name"
        name="name"
        value={inpval.name}
        onChange={setdata}
      />
    </div>

    <button type="submit" onClick={updatedata} class="btn btn-primary">
      Submit
    </button>
  </form>
</div>
  )
}

export default FormEdit
