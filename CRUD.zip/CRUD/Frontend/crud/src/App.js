
import './App.css';
import Form from './components/Form/Form';
import {Routes,Route} from "react-router-dom"
import UserTable from './components/table/UserTable';
import FormEdit from './components/FormEdit';



function App() {
  return (
    <>
    <Routes>
      <Route exact path ='/' element={<Form/>}></Route>
      <Route exact path ='/table' element={<UserTable/>}></Route>
      <Route exact path ='table/edit/:id' element={<FormEdit/>}></Route>

    </Routes>
    </>
  
  );
}

export default App;
